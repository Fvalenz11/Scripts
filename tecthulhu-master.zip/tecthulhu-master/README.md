A Tecthulhu software to control light and sound and interface with a Tecthulhu module on #MagnusReawakens

References:

Simple python test code to control WS2801 LEDs
http://realitysucks.blog.free.fr/index.php?post/2013/06/18/Communicating-with-WS2801-from-Raspberry-PI

AndyPi Raspberry Pi controlled WS2801 RGB LEDs - source for ws2801.py
https://andypi.co.uk/2014/12/27/raspberry-pi-controlled-ws2801-rgb-leds/

GPIO pinout of Raspi 3 Model B - need to connect MOSI, SCLK and GND to LED chain (ws2801 module)
http://pi4j.com/pins/model-3b-rev1.html

SPI Loopback test with C program - wire MOSI and MISO together
https://www.raspberrypi.org/documentation/hardware/raspberrypi/spi/README.md
